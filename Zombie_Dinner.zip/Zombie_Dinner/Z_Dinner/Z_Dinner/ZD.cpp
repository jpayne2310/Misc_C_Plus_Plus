#include <iostream>
#include <string>
#include <fstream>

using namespace std;

double cal_tax(double);
double cal_tip(double);



void main()
{

	cout.setf(ios::fixed, ios::floatfield);
	cout.setf(ios::showpoint);
	cout.precision(2);

	double meal, tax, tip, total_bill, tender, change;
	int rounds;
	char selection;

	cout << "Dinners Menu" << endl << endl;
	cout << "1. Peanut Butter & Jelly with water			$35.00" << endl;
	cout << "2. Steak, Fries, Vegtable, coffee and Soda		$45.00"<< endl << endl;
	cout << "Enter your selection...";
	cin >> selection;

	if (selection == '1')
	{
		meal = 35;
		tax = cal_tax(meal);
		tip = cal_tip(meal);
		total_bill = meal + tax + tip;	
	} 
	else
	{
		meal = 45;
		tax = cal_tax(meal);
		tip = cal_tip(meal);
		total_bill = meal + tax + tip;
	}

		system("cls");
		cout << "Your food cost is	$" << meal << endl;
		cout << "Food tax is		$" << tax << endl;
		cout << "Your tip is		$" << tip << endl << endl;
		cout << "Your food bill is	$" << total_bill << endl << endl;
		cout << "How much money do you have? ";
		cin >> tender;
		change = tender - total_bill;

		cout << endl << "You have $" << change << " left over" << endl << endl;

		rounds = ((int)change / 1 ) * 5;
		cout << "You can afford to buy " << rounds << " rounds of ammo.";
		cout << endl << endl << endl << endl;

		if(rounds < 15)
		{
			cout << "You do not have enough rounds to make it home" << endl;
			cout << "Better start washing dishes" << endl;
		}


	system("pause");

}

double cal_tax(double meal)
{
	double tax;
	tax = meal * .1;
	return tax;
}

double cal_tip(double meal)
{
	char selection;
	double tip;
	system("cls");
	cout << "Tip" << endl << endl;
	cout << "1. Exellent" << endl << endl;
	cout << "2. Good" << endl << endl;
	cout << "3. Fair" << endl << endl;
	cout << "4. Poor" << endl << endl;
	cout << "How was the service? ";
	cin >> selection;

	if (selection == '1')
	{
		tip = meal * .2;
	}
	else if (selection == '2')
	{
		tip = meal * .15;
	}
	else if (selection == '3')
	{
		tip = meal * .1;
	}
	else
	{
		tip = meal * .05;
	}
	return tip;
}
