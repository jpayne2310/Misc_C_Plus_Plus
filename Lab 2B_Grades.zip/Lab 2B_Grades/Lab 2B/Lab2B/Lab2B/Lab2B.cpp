#include <iostream>
#include <fstream>
#include <string>

using namespace std;

char NumberToLetter(double);

ifstream fin;

int grade1, grade2, grade3, grade4, grade5, num_of_records = 0;
double average;
string name;
char letter_grade;

void main()
{
	cout.precision(0);

	fin.open("tests.txt");

	 while (!fin.eof())
	 {
		 fin >> name >> grade1 >> grade2 >> grade3 >> grade4 >> grade5;

		 average = (grade1 + grade2 + grade3 + grade4 + grade5) / 5;
		 letter_grade = NumberToLetter(average);

		 cout << name << "\t" << average << "\t" << letter_grade << endl;

		 num_of_records ++;
	 }
	 cout << endl << endl;
	 cout << "Number of records processed " << num_of_records << endl << endl;

	system("pause");
}

char NumberToLetter(double average)
{
	if (average >= 90)
		{
			letter_grade = 'A';
		}
	else if (average >= 80)
		{
			letter_grade = 'B';
		}
	else if (average >= 70)
		{
			letter_grade = 'C';
		}
	else if (average >= 60)
		{
			letter_grade = 'D';
		}
	else
	{
		letter_grade = 'F';
	}
		return letter_grade;
}
