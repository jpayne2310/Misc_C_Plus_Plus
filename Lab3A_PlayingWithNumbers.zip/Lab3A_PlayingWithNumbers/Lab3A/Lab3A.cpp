#include <iostream>
#include<fstream>

using namespace std;

/* Write a C++ program the will display the largest number, smallest number, average of all the
numbers and the number of numbers processed. The file numbers.txt contains a column of
integers. There is one integer per line and only one column. The average must be rounded to 2
decimal places.*/


int smallest = 1000, largest, counter = 1, number,
	total_number = 0;
double ave;

ifstream fin;


void main()
{
	fin.open("numbers.txt");
	fin >> number;
	largest = number;
	smallest = number;
	total_number = total_number + number;
	do
	{

		cout << number << endl;
		fin >> number;
		
		counter++;

		

		if(number > largest)
		{
			largest = number;
		}
		else if (number < smallest)
		{
			smallest = number;
		}

		total_number = total_number + number;
	}while(!fin.eof());
	cout  << total_number << endl;
	cout << "The Largest Number is: " << largest << endl;
		cout << "The Smallest Number is: " << smallest << endl;
		ave = total_number / counter;
		cout << "The average of all the numbers is :" << ave << endl;
		cout << " Total numbers processed: " << counter << endl;



	system("pause");
}