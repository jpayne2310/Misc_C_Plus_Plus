#include <iostream>
#include<fstream>

using namespace std;

/* Write a C++ program the will display the largest number, smallest number, average of all the
numbers and the number of numbers processed. The file numbers.txt contains a column of
integers. There is one integer per line and only one column. The average must be rounded to 2
decimal places.*/


int smallest, largest, counter = 0, number,
	total_number = 0;
double ave;

int numbers[30];

ifstream fin;

void main()
{
	fin.open("numbers.txt");
	while(!fin.eof())
	{
		fin >> number;
		numbers[counter] = number;
		counter++;
	}

	//largest number
	largest = numbers[0];
	for(int i = 0; i < counter; i++)
	{
		if (numbers[i] > largest)
		{
			largest = numbers[i];
		}
	}
	cout << "The Largest number is " << largest << endl;

	//smallest number
	smallest = numbers[0];
	for(int i = 0; i < counter; i++)
	{
		if (numbers[i] < smallest)
		{
			smallest = numbers[i];
		}
	}
	cout << "The smallest number is " << smallest << endl;

	//average of all numbers
	for(int i = 0; i < counter; i++)
	{
		total_number = total_number + numbers[i];
	}
	ave = total_number / counter;
	cout << "The average of all the numbers is " << ave << endl;
 
	system("pause");
}