#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int id, age, m_not_e = 0, f_not_e = 0, m_not_reg, f_not_reg,
	no_vote = 0, vote = 0, processed = 0;
char gender, reg, voted;

ifstream fin;

void main()
{
	fin.open("vote.txt");
	fin >> id >> age  >> gender >> reg >> voted;
	while (!fin.eof())
	{
		processed++;
		if(age < 18)
			if(gender == 'M')
			{
				m_not_e++;
			}	else
			{
				f_not_e++;
			}	
		else if(reg == 'Y' && voted == 'N')
			{
				if(gender == 'M')
				{
					m_not_reg++;
				}
				else 
				{
					f_not_reg++;
				}
			}
		else if(voted == 'Y')
		{
			vote++;
		}
		else
		{
			no_vote++;
		}

		fin >> id >> age  >> gender >> reg >> voted;

	}

	cout << "Number of males not eligible to register " << m_not_e << endl;
	cout << "Number of females not eligible to register " << f_not_e << endl;
	cout << "Number of males who are old enough to vote but not registered "
		<< m_not_reg << endl;
	cout << "Number of females who are old enough to vote but not registered "
		<< f_not_reg << endl;
	cout << "Number of individuals who are eligible to vote but did not vote "
		<< no_vote << endl;
	cout << "Number of individuals who did vote " << vote << endl;
	cout << "Number of records processed " << processed << endl << endl;




	system("pause");
}

