#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;
int dice1, dice2, roll, combined_roll, point, win=0, lose=0;
bool game_over = false;
int roll_dice();
bool point_roll(int);

int main()
{
	srand(time(NULL));
	for(int i = 1; i <= 10000; i++)
	{
		game_over = false;
		while (game_over == false)
		{
			roll = 0;
			roll = roll_dice();
			//cout << "You rolled: " << roll << " " << endl;
			if(roll == 7 || roll ==11)
			{
				//cout << "You win!" << endl;
				game_over = true;
				win++;
			}
			else if(roll == 2 || roll == 3 || roll == 12)
			{
				//cout << "You Lose." << endl;
				game_over = true;
				lose++;
			}
			else
			{
				point = roll;
				point_roll(point);
			}
		}
	}
		cout << "Wins: " << win << endl;
		cout << "losses: " << lose << endl;
	system("pause");
	return 0;
}

bool point_roll(int point)
{
	//cout << "To win you need to roll: " << point << endl;
	while(game_over == false)
	{
		//srand(time(NULL));
		roll = 0;
		roll = roll_dice();
		//cout << "You rolled: " << roll << endl;
		if(roll == point)
		{
			//cout << "You rolled your point, You win!" << endl;
			game_over = true;
			win++;
		}
		else if(roll == 7)
		{
			//cout << "You lose." << endl;
			game_over = true;
			lose++;
		}
		else
		{
			//cout << "Roll again." << endl;
		}
	}

	return game_over;
}




int roll_dice()
{
	combined_roll = 0;
	dice1 = 0;
	dice1 = rand() % 6 + 1;
	dice2 = 0;
	dice2 = rand() % 6 + 1;
	combined_roll = dice1 + dice2;
	return combined_roll;
}