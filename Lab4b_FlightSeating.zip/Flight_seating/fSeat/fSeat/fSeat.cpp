#include <iostream>


using namespace std;

char pass_row1[5] = {'A','B','C','D'};
char pass_row2[5] = {'A','B','C','D'};

char seat,answer = 'Y';

int seat_count = 0, seat_assignment, row;

void seating();
char convert_seat(int);

int main()
{
	while(answer == 'Y' && seat_count < 8)
	{
		cout << "Here is the current seat availability: " << endl
			<<endl;
		seating();
		cout << "Please enter the row you would like: ";
		cin >> row;
		cout << "Please enter the seat you would prefer." << endl;
		cout << "Choose A, B, C, or D (X is unavailable): ";
		cin >> seat;
		seat = toupper(seat);
			while(seat != 'A' && seat !='B' && seat !='C' && seat !='D')
			{
				cout << "Incorreect responce." << endl;
				cout << "You must choose A, B, C, or D" << endl;
				cout << "Please re-enter your selection: ";
				cin >> seat;
				seat = toupper(seat);
			}
		seat_assignment = convert_seat(seat);
		if( row == 1)
		{
			if(pass_row1[seat_assignment] != 'X')
			{
				pass_row1[seat_assignment] = 'X';
				cout << "That seat is available and now reserved for you!" << endl;
				seat_count++;
			}
			else
			{
				cout << "Sorry, that seat is not available." << endl;
			}
		}
		else if(row == 2)
		{
			if(pass_row2[seat_assignment] != 'X')
			{
				pass_row2[seat_assignment] = 'X';
				cout << "That seat is available and now reserved for you!" << endl;
				seat_count++;
			}
			else 
			{
				cout << "Sorry, that seat is not available." << endl;
			}
		}
		else
		{
			cout << "Sorry, any row other than 1 & 2 is currently unavailable" << endl;
			cout << "Due to 'Pasteing'" << endl;
		}
		cout << "Would you like to reserve another seat? (Y/N): ";
		cin >> answer;
		answer = toupper(answer);
		system("cls");
	}
	if (seat_count == 8)
	{
		cout << "Sorry no more seat available for this flight."<< endl;
	}
	cout << "Thank You for choosing Reckless Airways!" << endl;
	system("pause");
	return 0 ;
}

void seating()
{
	cout << "Row 1:\t" << pass_row1[0] << "\t" << pass_row1[1] 
	<< "\t" << pass_row1[2] << "\t" << pass_row1[3] << endl;
	cout << "Row 2:\t" << pass_row2[0] << "\t" << pass_row2[1] 
	<< "\t" << pass_row2[2] << "\t" << pass_row2[3] << endl;
	for(int i = 3; i < 5; i++)
	{
		cout << "Row " << i << ";\t" << "A\t" << "B\t" << "C\t"
			<< "D" << endl;
	}
	cout << endl;
	for(int i = 5; i < 9; i++)
	{
		cout << "Row " << i << ";\t" << "A\t" << "B\t" << "C\t"
			<< "D" << endl;
	}

}

char convert_seat(int)
{
	if(seat == 'A')
	{
		seat_assignment = 0;
	}
	else if(seat == 'B')
	{
		seat_assignment = 1;
	}
	else if(seat == 'C')
	{
		seat_assignment = 2;
	}
	else
	{
		seat_assignment = 3;
	}

	return seat_assignment;
}